var express =require('express');
var session = require('express-session'); // for login operations
var path =require('path');
var app =express();

//body parser requirements
var bodyParser=require('body-parser');
app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));
app.use(bodyParser.json());
var urlencodedParser=bodyParser.urlencoded({extended:false});

//importing routes
const homeRoutes = require('./routes/home');
const adminRoutes =require('./routes/admin');
const memberRoutes =require('./routes/member');
const visitorRoutes =require('./routes/visitor');
//settings
app.set('view engine','ejs');
app.set('views',path.join(__dirname ,'views'));

//static files
app.use("/public",express.static('./public/'));

//routes
app.use('/',homeRoutes);
app.use('/',adminRoutes);
app.use('/',memberRoutes);
app.use('/',visitorRoutes);


app.listen(3030);
console.log('Bağlandın');
