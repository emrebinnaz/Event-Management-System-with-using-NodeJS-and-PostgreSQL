const categoriesController={};
const {Pool,Client}=require('pg');
const connectionString='postgressql://postgres:1234567890*@localhost:5432/EMS'
const client =new Client({
    connectionString:connectionString
});
client.connect();

categoriesController.list=(req,res) =>{
    client.query('SELECT * FROM Category',(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.render('categories',{categories:(data.rows)});   
   });
};

categoriesController.add=(req,res)=>{
    res.render('addCategory');
};

categoriesController.saveAdding=(req,res)=>{
    var name = req.body.Name; 
    client.query('INSERT INTO Category ("Name") VALUES ($1)',[name],(err,data)=>{
       res.redirect('/admin/categories'); 
    });
};
categoriesController.delete=(req,res)=>{
    client.query('SELECT * from Category WHERE "isDeleted"=false',(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.render('deleteCategory',{categories:(data.rows)});   
   });
};

categoriesController.saveDeleting=(req,res)=>{
req.body.Id=req.body.Id.split(" ");
    client.query('UPDATE Category SET "isDeleted"=true WHERE "Id"=$1',[req.body.Id[0]],(error,data)=>{
       res.redirect('/admin/categories');
   });
};
categoriesController.update=(req,res)=>{
    const { id } = req.params;
    client.query('SELECT * from Category WHERE "Id"=$1',[id],(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.render('updateCategory',{categories:(data.rows)});  
      
       }); 
};
categoriesController.saveUpdating=(req,res)=>{
    const { id } = req.params;
    var newName=req.body.Name;
    client.query('CALL updateCategory($1,$2)',[newName,id],(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.redirect('/admin/categories');
       });
};

module.exports = categoriesController;