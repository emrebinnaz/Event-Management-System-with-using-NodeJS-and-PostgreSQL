const eventsController={};
const {Pool,Client}=require('pg');
const connectionString='postgressql://postgres:1234567890*@localhost:5432/EMS'
const client =new Client({
    connectionString:connectionString
});
client.connect();

//admin functions
eventsController.list=(req,res) =>{

    client.query('SELECT * from Events',(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.render('eventsForAdmin',{events:(data.rows)});  
   });
};
eventsController.add=(req,res) => {

    client.query('SELECT * FROM Organizators WHERE "DeleteDate" is null',(error,data)=>{
        if(error) {
            console.log(error);
        }
    client.query('SELECT * FROM Category WHERE "isDeleted"=false',(error,data1)=>{
        if(error) {
            console.log(error);
        }
        res.render('addEvent',{organizators:data.rows,categories:data1.rows});
        });        
    });
};
eventsController.saveAdding=(req,res)=>{

    req.body.CategoryId=req.body.CategoryId.split(" ");
    client.query('INSERT INTO Events ("Name","Organizator_Username","Address","Price","Discount","StartDate","EndDate","City","Quota","Category_Id") VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',
    [req.body.Name,req.body.OrganizatorUsername,req.body.Address,req.body.Price,req.body.Discount,req.body.StartDate,req.body.EndDate,req.body.City,req.body.Quota,req.body.CategoryId[0]],(error,data)=>{
        res.redirect('/admin/events');
    });
};
eventsController.delete=(req,res)=>{

    client.query('SELECT * from Events WHERE "isDeleted"=false',(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.render('deleteEvent',{events:(data.rows)});   
   });
};
eventsController.saveDeleting=(req,res)=>{

    req.body.Id=req.body.Id.split(" ");
    client.query('UPDATE Events SET "isDeleted"=true WHERE "Id"=$1',[req.body.Id[0]],(error,data)=>{
       res.redirect('/admin/events');
   });
};
eventsController.update=(req,res)=>{

    const { id } = req.params;
    client.query('SELECT * from Events WHERE "Id"=$1',[id],(error,data2)=>{
        if(error) {
            console.log(error);
        }
        client.query('SELECT * FROM Organizators WHERE "DeleteDate" is null',(error,data)=>{
            if(error) {
                console.log(error);
            }
            client.query('SELECT * FROM Category WHERE "isDeleted"=false',(error,data1)=>{
                if(error) {
                    console.log(error);
                }
             res.render('updateEvent',{organizators:data.rows,categories:data1.rows,event:data2.rows});  
            });        
        });
    });
};
eventsController.saveUpdating=(req,res)=>{

    const { id } = req.params;
    var newStartDate=new Date(req.body.StartDate).toUTCString();
    var newEndDate=new Date(req.body.EndDate).toUTCString();
    req.body.CategoryId=req.body.CategoryId.split(" ");
    client.query('UPDATE Events set "Name"=$1,"Organizator_Username"=$2, "Address"=$3 ,"Price" =$4 , "Discount" =$5 , "StartDate"=$6 ,"EndDate"=$7, "City"=$8 , "Quota"=$9 , "Category_Id"=$10 WHERE "Id"=$11', 
    [req.body.Name,req.body.OrganizatorUsername,req.body.Address,req.body.Price,req.body.Discount,newStartDate,newEndDate,req.body.City,req.body.Quota,req.body.CategoryId[0],id],(error,data)=>{
        if(error) {
            console.log(error);
        } 
        res.redirect('/admin/events');
       });
};
eventsController.see=(req,res)=>{

    const{id}=req.params;
    client.query('SELECT p.*,pie."SoldDate" from PeopleInEvents AS pie  INNER JOIN People AS P ON pie."P_Id"=p."Id" WHERE "E_Id"=$1',[id],(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.render('seeParticipants',{people:(data.rows)});   
   });
};
eventsController.seeLogins=(req,res)=>{
    
    client.query('SELECT * from Logins',(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.render('seeLogins',{person:(data.rows)});  
   });
};

//member functions
eventsController.listForMember=(req,res) =>{
  
    const { id } = req.params;
    client.query('SELECT * from EventsView',(error,data)=>{
        if(error) {
            console.log(error);
        }
        else{
            client.query('SELECT * from EventsView as ev inner join PeopleInEvents as pie on ev."e_id"=pie."E_Id" WHERE pie."P_Id"=$1',[id],(error,data2)=>{
                res.render('eventsForMember',{events:data.rows,events2:data2.rows,id:id});  
            });
        }
   }); 
};
eventsController.joinedEvents=(req,res) =>{
    
    const { id } = req.params; 
    client.query('SELECT * from MyEventsView WHERE "P_Id"=$1',[id],(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.render('joinedEventsForMember',{events:(data.rows)});  
   });
};
eventsController.buyEventForMember=(req,res)=> {
    
        var date= new Date();
        var x=0;
        client.query('INSERT INTO PeopleInEvents ("E_Id","P_Id","SoldDate","PaymentAmount") VALUES ($1,$2,$3,$4)',[req.params.e_id,req.params.m_id,date,x],(error,data)=>{
            if(error) {
                console.log(error);
            }  
           
        });
        client.query('SELECT * FROM PeopleInEvents WHERE  "E_Id"=$1 AND "P_Id"=$2',[req.params.e_id,req.params.m_id],(error,data)=>{
            if(error) {
                console.log(error);
            }  
            res.render('buyEventForMember',{event:(data.rows)});
        });    
};
eventsController.filterEvents=(req,res)=>{
   var m_id=req.params;
    client.query('SELECT DISTINCT "City" FROM Events ',(error,data)=>{
        if(error) {
            console.log(error);
        }  
        client.query('SELECT "Name" FROM Category ',(error,data1)=>{
            if(error) {
                console.log(error);
            }             
            client.query('SELECT  DISTINCT "Name"  FROM Events',(error,data2)=>{
                if(error) {
                    console.log(error);
                }     
                res.render('filteringEvents',{cities:data.rows,categories:data1.rows,events:data2.rows,member:m_id});
             });     
           
        });    
    });    
};
eventsController.showFilteredEvents=(req,res)=>{
    
    var c_name =req.body.CategoryName;
    var e_name =req.body.EventName;
    var e_city =req.body.EventsCity;
    
    client.query('SELECT * from EventsView WHERE "Name"=$1 or "City"=$2 or "c_name"=$3' ,[req.body.EventName,req.body.EventsCity,req.body.CategoryName],(error,data)=>{
        if(error) {
            console.log(error);
        }
        else{
            client.query('SELECT * from EventsView as ev inner join PeopleInEvents as pie on ev."e_id"=pie."E_Id" WHERE pie."P_Id"=$1',[req.params.id],(error,data2)=>{
                res.render('showFilteredEventsForMember',{events:data.rows,events2:data2.rows,id:req.params.id});  
            });
        }
   });   
};

//visitor functions
eventsController.listForVisitor=(req,res)=>{

    client.query('SELECT * from EventsView',(error,data)=>{
        if(error) {
            console.log(error);
        }
       res.render('eventsForVisitors',{events:(data.rows)});
   }); 
};

eventsController.eventInfoForVisitor=(req,res)=>{

    var date = new Date().toString().replace(/T/, ':').replace(/\.\w*/, '');
    client.query('SELECT * from EventsView inner join PeopleInEvents as pie on EventsView."e_id"=pie."E_Id" where pie."TempVisitor_Id"=$1 and pie."E_Id"=$2',
    [req.body.TempVisitor_Id,req.body.EventId],(error,data)=>{
        if(error) {
            console.log(error);
        }
        client.query('SELECT * FROM People as p inner join  PeopleInEvents as pie on pie."P_Id"=p."Id" WHERE pie."TempVisitor_Id"=$1',[req.body.TempVisitor_Id],(error,data1)=>{
            if(error) {
                console.log(error);
            }
            client.query('INSERT INTO Logins ("Name","Lastname","Id","TempVisitor_Id","EnteringDate") VALUES($1,$2,$3,$4,$5)',[data1.rows[0].Name,data1.rows[0].Lastname,data1.rows[0].Id,req.body.TempVisitor_Id,date],(error,data2)=>{
                if(error) {
                    console.log(error);
                }  
            });   
        }); 
       res.render('eventInfoForVisitor',{events:(data.rows)});
   }); 
};
eventsController.registrationForVisitor=(req,res)=>{

    var e_id =req.params.id;
    client.query('SELECT * FROM Events WHERE "Id"=$1',[e_id],(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.render('registrationForVisitor',{event:(data.rows)});  
    });
}
eventsController.saveRegistrationForVisitor=(req,res)=>{

    var e_id =req.params.e_id;
    var date =new Date();
    var newBirthDate=new Date(req.body.Birthdate).toUTCString();
    client.query('INSERT INTO People ("Name","Lastname","Phone","Address","Email","BirthDate")VALUES($1,$2,$3,$4,$5,$6)',
    [req.body.Name,req.body.Lastname,req.body.Phone,req.body.Address,req.body.Email,newBirthDate],(error,data)=>{
        if(error) {
            console.log(error);
        }
        client.query('SELECT * FROM People WHERE "Id"=(SELECT max("Id") FROM People)',(error,data1)=>{
            if(error) {
                console.log(error);
            }
                client.query('INSERT INTO PeopleInEvents ("E_Id","P_Id","SoldDate","TempVisitor_Id") VALUES ($1,$2,$3,$4)',[e_id,data1.rows[0].Id,date,null],(error,data2)=>{ 
                if(error) {
                    console.log(error);
                }
                else{
                    client.query('SELECT "E_Id","P_Id","SoldDate","TempVisitor_Id","isPay","PaymentAmount" FROM PeopleInEvents WHERE "P_Id"=$1 and "E_Id"=$2',[data1.rows[0].Id,e_id],(error,data3)=>{
                        if(error) {
                            console.log(error);
                        }
                        res.render('buyEventForVisitor',{event:(data3.rows)}); 
                    });

                } 
            });  
        });
    });
};

module.exports = eventsController;