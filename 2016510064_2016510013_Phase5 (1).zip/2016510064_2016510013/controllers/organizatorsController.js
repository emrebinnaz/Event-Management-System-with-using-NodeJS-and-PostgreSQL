const organizatorsController={};
const {Pool,Client}=require('pg');
const connectionString='postgressql://postgres:1234567890*@localhost:5432/EMS'
const client =new Client({
    connectionString:connectionString
});
client.connect();

organizatorsController.list=(req,res) =>{
    client.query('SELECT * from Organizators',(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.render('organizators',{organizators:(data.rows)});  
   });
};

organizatorsController.add=(req,res) => {
  res.render('addOrganizator');
};

organizatorsController.saveAdding=(req,res)=>{
    var birthdate=new Date(req.body.Birthdate).toUTCString();
    client.query('SELECT * from Organizators WHERE "Username"=$1 AND EXISTS (SELECT *from Organizators WHERE "Username"=$1)',[req.body.Username],(error,data)=>{
        if(error) {
            console.log(error);
        }
        if(data.rows[0]!=null){
            client.query('UPDATE Organizators SET "Password"=$1,"Name"=$2,"Lastname"=$3,"Phone"=$4,"Email"=$5,"Address"=$6,"BirthDate"=$7,"DeleteDate"=null WHERE "Username"=$8',[req.body.Password,req.body.Name,req.body.Lastname,req.body.Phone,req.body.Email,req.body.Address,birthdate,req.body.Username],(error,data)=>{
                res.redirect('/admin/organizators');
            });
        }
        else{  
            client.query('INSERT INTO Organizators ("Username","Password","Name","Lastname","Phone","Email","Address","BirthDate") VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
            [req.body.Username,req.body.Password,req.body.Name,req.body.Lastname,req.body.Phone,req.body.Email,req.body.Address,birthdate],(error,data)=>{
             res.redirect('/admin/organizators');
            });
        }
    });
};
organizatorsController.delete=(req,res)=>{
    client.query('SELECT * from Organizators WHERE "DeleteDate"is null AND "isSuperAdmin"=false',(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.render('deleteOrganizator',{organizators:(data.rows)});   
   });
};

organizatorsController.saveDeleting=(req,res)=>{
    var datetime = new Date(); 
    client.query('UPDATE Organizators SET "DeleteDate"=$1 WHERE "Username"=$2 AND "isSuperAdmin"=false',[datetime,req.body.Username],(error,data)=>{
        res.redirect('/admin/organizators');
    });  
};

organizatorsController.update=(req,res)=>{
    const {username} = req.params;
    client.query('SELECT * FROM Organizators WHERE "Username"=$1',[username],(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.render('updateOrganizator',{organizators:(data.rows)});
    });
    
};
organizatorsController.saveUpdating=(req,res)=>{
    const { username } = req.params;
    var newBirthDate=new Date(req.body.Birthdate).toUTCString();
    client.query('UPDATE Organizators set "Username"=$1,"Password"=$2, "Name"=$3 ,"Lastname" =$4 , "Phone" =$5 , "Email"=$6 ,"Address"=$7, "BirthDate"=$8,"isSuperAdmin"=$9 WHERE "Username"=$10', 
    [req.body.Username,req.body.Password,req.body.Name,req.body.Lastname,req.body.Phone,req.body.Email,req.body.Address,newBirthDate,req.body.isSuperAdmin,username],(error,data)=>{
        if(error) {
            console.log(error);
        }
        res.redirect('/admin/organizators');
        //organizaötr kendi ismini güncellerse menuye dönünce page sıkıntı cıkartıyor.
       }); 
};

module.exports = organizatorsController;