const homeController ={};
const {Pool,Client}=require('pg');
const connectionString='postgressql://postgres:1234567890*@localhost:5432/EMS'
const client =new Client({
    connectionString:connectionString
});
client.connect();

var a_username;
var a_password;
var m_username;
var m_password;

homeController.welcome =(req,res,err)=>{
    if(err){
        console.log(err);
    }
    res.render('home');
};
homeController.login=(req,res,err)=>{ 
    
     a_username = req.body.Username;
     a_password = req.body.Password;
     
    if(a_username && a_password) {
        client.query('SELECT * from ORGANIZATORS WHERE "Username"=$1 AND "Password"=$2 AND "isSuperAdmin"=true',[a_username,a_password],
        (error,data)=>{
            if(err) {
                console.log(err);
            }
            if(data.rows[0]==null)
            {
                res.send('Incorrect Username and/or Password!');   
            }
            else if (data.rows[0].Username==a_username && data.rows[0].Password==a_password) {
                req.session.loggedin = true;
                req.session.username = a_username;   
                req.session.password = a_password;
                res.render('adminPanel',{admin:(data.rows)});
            }	
            res.end();  
        });
    }  
};
homeController.adminPanel=(req,res,err)=>{ 

    client.query('SELECT * from ORGANIZATORS WHERE "Username"=$1 AND EXISTS (SELECT *from ORGANIZATORS WHERE "Username"=$1 )',[a_username],
        (err,data)=>{
            if(err) {
                console.log(err);
            } 
            if(data.rows[0]!=null){
                res.render('adminPanel',{admin:(data.rows)}); 
            } 
            else if(data.rows[0]==null){
                res.render('home');
            } 
        });
};

homeController.memberLogin=(req,res,err)=>{ 
    
    m_username = req.body.Username;
    m_password = req.body.Password;
    var date = new Date().toString().replace(/T/, ':').replace(/\.\w*/, '');
   if(m_username && m_password) {
       client.query('SELECT * from People WHERE "Username"=$1 AND "Password"=$2 AND "DeleteDate" is null',[m_username,m_password],
       (error,data)=>{
           if(err) {
               console.log(err);
           }
           if(data.rows[0]==null)
           {
               res.send('Incorrect Username and/or Password!');   
           }
           else if (data.rows[0].Username==m_username && data.rows[0].Password==m_password) {
               req.session.loggedin = true;
               req.session.username = m_username;   
               req.session.password = m_password;
               client.query('INSERT INTO Logins ("Username","Name","Lastname","Id","EnteringDate") VALUES ($1,$2,$3,$4,$5) ',[m_username,data.rows[0].Name,data.rows[0].Lastname,data.rows[0].Id,date],
               (err,data)=>{
                   if(err) {
                       console.log(err);
                   } 
                });   
               res.render('memberPanel',{member:(data.rows)});
           }	
           res.end();  
       });
   }  
};
homeController.memberPanel=(req,res,err)=>{ 

   client.query('SELECT * from People WHERE "Username"=$1',[m_username],
       (err,data)=>{
           if(err) {
               console.log(err);
           } 
           else {
               res.render('memberPanel',{member:(data.rows)}); 
           } 
        });
};

module.exports = homeController;