const express =require('express');
const homeRouter = express.Router();
const homeController= require('../controllers/homeController');
var bodyParser=require('body-parser');
var urlencodedParser=bodyParser.urlencoded({extended:false});

homeRouter.get('/',homeController.welcome);
homeRouter.get('/admin/',homeController.adminPanel);
homeRouter.post('/admin/',urlencodedParser,homeController.login);
homeRouter.get('/member/',homeController.memberPanel);
homeRouter.post('/member/',urlencodedParser,homeController.memberLogin);

module.exports = homeRouter;