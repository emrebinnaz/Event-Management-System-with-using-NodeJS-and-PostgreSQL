const express =require('express');
const visitorRouter = express.Router();
var bodyParser=require('body-parser');
var urlencodedParser=bodyParser.urlencoded({extended:false});

const eventsController = require('../controllers/eventsController');

visitorRouter.get('/visitor/events',eventsController.listForVisitor);
visitorRouter.post('/visitor/myEvent',urlencodedParser,eventsController.eventInfoForVisitor);
visitorRouter.get('/visitor/events/:id',eventsController.registrationForVisitor);
visitorRouter.post('/visitor/events/:e_id',urlencodedParser,eventsController.saveRegistrationForVisitor);

module.exports = visitorRouter;