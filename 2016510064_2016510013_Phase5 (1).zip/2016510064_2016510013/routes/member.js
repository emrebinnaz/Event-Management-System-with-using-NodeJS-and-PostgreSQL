const express =require('express');
const memberRouter = express.Router();
var bodyParser=require('body-parser');
var urlencodedParser=bodyParser.urlencoded({extended:false});

const eventsController = require('../controllers/eventsController');

memberRouter.get('/member/:id/events',eventsController.listForMember);
memberRouter.get('/member/myEventsList/:id',urlencodedParser,eventsController.joinedEvents);
memberRouter.get('/member/:m_id/filter',urlencodedParser,eventsController.filterEvents);
memberRouter.post('/member/:id/filter',urlencodedParser,eventsController.showFilteredEvents);
memberRouter.get('/member/:m_id/events/buy/:e_id',urlencodedParser,eventsController.buyEventForMember);

module.exports = memberRouter;