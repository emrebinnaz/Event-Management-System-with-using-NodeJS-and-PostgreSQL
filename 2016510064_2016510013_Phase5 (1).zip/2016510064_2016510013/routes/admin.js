const express =require('express');
const adminRouter = express.Router();
var bodyParser=require('body-parser');
var urlencodedParser=bodyParser.urlencoded({extended:false});

const eventsController = require('../controllers/eventsController');
const categoriesController =require('../controllers/categoriesController');
const organizatorsController=require('../controllers/organizatorsController');

adminRouter.get('/admin/events',eventsController.list);
adminRouter.get('/admin/events/add',eventsController.add);
adminRouter.post('/admin/events/add',urlencodedParser,eventsController.saveAdding);
adminRouter.get('/admin/events/delete',eventsController.delete);
adminRouter.post('/admin/events/delete',urlencodedParser,eventsController.saveDeleting);
adminRouter.get('/admin/events/:id',urlencodedParser,eventsController.update);
adminRouter.post('/admin/events/:id',urlencodedParser,eventsController.saveUpdating);
adminRouter.get('/admin/events/:id/see',urlencodedParser,eventsController.see);
adminRouter.get('/admin/logins',eventsController.seeLogins);

adminRouter.get('/admin/categories',categoriesController.list);
adminRouter.get('/admin/categories/add',urlencodedParser,categoriesController.add);
adminRouter.post('/admin/categories/add',urlencodedParser,categoriesController.saveAdding);
adminRouter.get('/admin/categories/delete',categoriesController.delete);
adminRouter.post('/admin/categories/delete',urlencodedParser,categoriesController.saveDeleting);
adminRouter.get('/admin/categories/:id',urlencodedParser,categoriesController.update);
adminRouter.post('/admin/categories/:id',urlencodedParser,categoriesController.saveUpdating);

adminRouter.get('/admin/organizators',organizatorsController.list);
adminRouter.get('/admin/organizators/add',urlencodedParser,organizatorsController.add);
adminRouter.post('/admin/organizators/add',urlencodedParser,organizatorsController.saveAdding);
adminRouter.get('/admin/organizators/delete',organizatorsController.delete);
adminRouter.post('/admin/organizators/delete',urlencodedParser,organizatorsController.saveDeleting);
adminRouter.get('/admin/organizators/:username',urlencodedParser,organizatorsController.update);
adminRouter.post('/admin/organizators/:username',urlencodedParser,organizatorsController.saveUpdating);

module.exports = adminRouter;